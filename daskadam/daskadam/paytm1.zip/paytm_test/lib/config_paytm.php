<?php
//Change the value of PAYTM_MERCHANT_KEY constant with details received from Paytm.
//test

// define('PAYTM_MERCHANT_KEY', 'AmgwJA45123063672462');
define('PAYTM_MERCHANT_KEY', 'AK2lwI4s4XjBeMll');

?>
