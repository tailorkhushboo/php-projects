<?php
//Change the value of PAYTM_MERCHANT_KEY constant with details received from Paytm.
//test

// define('PAYTM_MERCHANT_KEY', 'AmgwJA45123063672462');
define('PAYTM_MERCHANT_KEY', 'l1Xpx9sZBYyoGOnr');

?>
